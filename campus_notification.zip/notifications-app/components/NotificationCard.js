'use client';
import { Card, CardContent, Typography, Chip, Box, IconButton, Tooltip } from '@mui/material';
import WorkIcon from '@mui/icons-material/Work';
import SchoolIcon from '@mui/icons-material/School';
import EventIcon from '@mui/icons-material/Event';
import MarkEmailReadIcon from '@mui/icons-material/MarkEmailRead';
import MarkEmailUnreadIcon from '@mui/icons-material/MarkEmailUnread';

const categoryStyles = {
  Placement: {
    color: 'success',
    icon: <WorkIcon sx={{ fontSize: 14 }} />,
    label: 'Placement',
    bg: '#E8F5E9',
    border: '#43A047',
  },
  Result: {
    color: 'warning',
    icon: <SchoolIcon sx={{ fontSize: 14 }} />,
    label: 'Result',
    bg: '#FFF8E1',
    border: '#FB8C00',
  },
  Event: {
    color: 'info',
    icon: <EventIcon sx={{ fontSize: 14 }} />,
    label: 'Event',
    bg: '#E3F2FD',
    border: '#1E88E5',
  },
};

function elapsedLabel(timestamp) {
  const totalMinutes = Math.floor((Date.now() - new Date(timestamp).getTime()) / 60000);
  if (totalMinutes < 1) return 'just now';
  if (totalMinutes < 60) return `${totalMinutes}m ago`;
  const hours = Math.floor(totalMinutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export default function NotificationCard({ notification, isRead, onToggleRead }) {
  const style = categoryStyles[notification.Type] ?? {
    color: 'default',
    icon: null,
    label: notification.Type,
    bg: '#F5F5F5',
    border: '#9E9E9E',
  };

  const shortId = notification.ID.slice(0, 8);

  return (
    <Card
      elevation={0}
      sx={{
        border: '1px solid',
        borderColor: isRead ? '#E0E0E0' : style.border,
        borderLeft: '4px solid',
        borderLeftColor: isRead ? '#BDBDBD' : style.border,
        bgcolor: isRead ? '#FAFAFA' : style.bg,
        transition: 'all 0.2s ease',
        '&:hover': { boxShadow: '0 2px 12px rgba(0,0,0,0.1)', transform: 'translateY(-1px)' },
        opacity: isRead ? 0.75 : 1,
      }}
    >
      <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
            <Chip
              icon={style.icon}
              label={style.label}
              color={style.color}
              size="small"
              variant="outlined"
              sx={{ fontWeight: 600, fontSize: 11 }}
            />
            {!isRead && (
              <Chip
                label="NEW"
                size="small"
                color="primary"
                sx={{ fontWeight: 700, fontSize: 10, height: 18 }}
              />
            )}
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flexShrink: 0 }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontSize: 11 }}>
              {elapsedLabel(notification.Timestamp)}
            </Typography>
            <Tooltip title={isRead ? 'Mark as unread' : 'Mark as read'}>
              <IconButton size="small" onClick={() => onToggleRead(notification.ID)}>
                {isRead
                  ? <MarkEmailUnreadIcon sx={{ fontSize: 16 }} />
                  : <MarkEmailReadIcon sx={{ fontSize: 16 }} />}
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        <Typography
          variant="body1"
          fontWeight={isRead ? 400 : 600}
          sx={{ mt: 0.75, fontSize: 14, color: isRead ? 'text.secondary' : 'text.primary' }}
        >
          {notification.Message}
        </Typography>

        <Typography variant="caption" color="text.disabled" sx={{ mt: 0.25, display: 'block', fontSize: 11 }}>
          {new Date(notification.Timestamp).toLocaleString()} · {shortId}…
        </Typography>
      </CardContent>
    </Card>
  );
}
