'use client';
import { AppBar, Toolbar, Typography, Button, Box, Badge, Chip } from '@mui/material';
import NotificationsIcon from '@mui/icons-material/Notifications';
import StarIcon from '@mui/icons-material/Star';
import CampaignIcon from '@mui/icons-material/Campaign';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const routes = [
  { href: '/notifications', label: 'All Notifications', icon: 'bell' },
  { href: '/priority', label: 'Priority Inbox', icon: 'star' },
];

function NavLink({ href, label, icon, pendingCount, currentPath }) {
  const isActive = currentPath === href;

  const resolvedIcon =
    icon === 'bell' ? (
      <Badge badgeContent={pendingCount} color="error" max={99}>
        <NotificationsIcon />
      </Badge>
    ) : (
      <StarIcon />
    );

  return (
    <Button
      component={Link}
      href={href}
      startIcon={resolvedIcon}
      sx={{
        color: 'white',
        fontWeight: isActive ? 700 : 400,
        bgcolor: isActive ? 'rgba(255,255,255,0.15)' : 'transparent',
        borderRadius: 2,
        px: 2,
        '&:hover': { bgcolor: 'rgba(255,255,255,0.1)' },
      }}
    >
      {label}
    </Button>
  );
}

export default function Navbar({ unreadCount = 0 }) {
  const currentPath = usePathname();

  return (
    <AppBar position="sticky" elevation={2} sx={{ bgcolor: '#0D47A1' }}>
      <Toolbar sx={{ gap: 1 }}>
        <CampaignIcon sx={{ mr: 1 }} />
        <Typography variant="h6" fontWeight={700} sx={{ flexGrow: 1, letterSpacing: '-0.5px' }}>
          Campus Notify
        </Typography>
        {unreadCount > 0 && (
          <Chip
            label={`${unreadCount} unread`}
            size="small"
            sx={{ bgcolor: '#EF5350', color: 'white', fontWeight: 600, fontSize: 11, mr: 1 }}
          />
        )}
        <Box sx={{ display: 'flex', gap: 0.5 }}>
          {routes.map((r) => (
            <NavLink
              key={r.href}
              href={r.href}
              label={r.label}
              icon={r.icon}
              pendingCount={unreadCount}
              currentPath={currentPath}
            />
          ))}
        </Box>
      </Toolbar>
    </AppBar>
  );
}
