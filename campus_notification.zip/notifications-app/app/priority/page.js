'use client';
import { useState, useEffect, useCallback } from 'react';
import {
  Container, Box, Typography, Slider, CircularProgress, Alert,
  Stack, Chip, ToggleButtonGroup, ToggleButton, Paper, Divider,
  LinearProgress, Tooltip,
} from '@mui/material';
import StarIcon from '@mui/icons-material/Star';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import FilterListIcon from '@mui/icons-material/FilterList';
import Navbar from '@/components/Navbar';
import NotificationCard from '@/components/NotificationCard';
import { fetchNotifications, priorityScore } from '@/lib/api';
import { logger } from '@/lib/logger';

const CATEGORY_OPTIONS = ['All', 'Placement', 'Result', 'Event'];
const REFRESH_INTERVAL = 30;

function getRankColor(position) {
  if (position === 0) return '#FFD700';
  if (position === 1) return '#C0C0C0';
  if (position === 2) return '#CD7F32';
  return '#E0E0E0';
}

export default function PriorityPage() {
  const [pool, setPool] = useState([]);
  const [displayLimit, setDisplayLimit] = useState(10);
  const [activeCategory, setActiveCategory] = useState('All');
  const [isFetching, setIsFetching] = useState(false);
  const [fetchError, setFetchError] = useState(null);
  const [seenIds, setSeenIds] = useState(new Set());
  const [ticker, setTicker] = useState(REFRESH_INTERVAL);
  const [refreshedAt, setRefreshedAt] = useState(null);

  const loadData = useCallback(async () => {
    setIsFetching(true);
    setFetchError(null);
    logger.info('priority-page', 'Fetching notifications for priority ranking', { displayLimit });

    try {
      const result = await fetchNotifications({ page: 1, limit: 50 });
      setPool(result);
      setRefreshedAt(new Date());
      setTicker(REFRESH_INTERVAL);
      logger.info('priority-page', 'Priority data loaded', { count: result.length });
    } catch (err) {
      setFetchError(err.message);
      logger.error('priority-page', 'Priority load failed', { error: err.message });
    } finally {
      setIsFetching(false);
    }
  }, [displayLimit]);

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTicker((t) => {
        if (t <= 1) {
          logger.info('priority-page', 'Auto-refreshing priority inbox');
          loadData();
          return REFRESH_INTERVAL;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [loadData]);

  const toggleRead = (id) => {
    setSeenIds((prev) => {
      const updated = new Set(prev);
      if (updated.has(id)) updated.delete(id);
      else updated.add(id);
      logger.info('priority-page', 'Toggled read', { id });
      return updated;
    });
  };

  const rankedItems = [...pool]
    .filter((n) => activeCategory === 'All' || n.Type === activeCategory)
    .sort((a, b) => priorityScore(b) - priorityScore(a))
    .slice(0, displayLimit);

  const pendingCount = rankedItems.filter((n) => !seenIds.has(n.ID)).length;
  const progressValue = ((REFRESH_INTERVAL - ticker) / REFRESH_INTERVAL) * 100;

  return (
    <>
      <Navbar unreadCount={pendingCount} />
      <Box sx={{ bgcolor: 'background.default', minHeight: '100vh', py: 4 }}>
        <Container maxWidth="md">

          <Paper elevation={0} sx={{ p: 3, mb: 3, border: '1px solid #E0E0E0' }}>
            <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', mb: 2 }}>
              <Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <StarIcon sx={{ color: '#FB8C00', fontSize: 28 }} />
                  <Typography variant="h5" fontWeight={700} color="primary">
                    Priority Inbox
                  </Typography>
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                  Ranked by type weight (Placement › Result › Event) + recency
                </Typography>
                {refreshedAt && (
                  <Typography variant="caption" color="text.disabled">
                    Last updated: {refreshedAt.toLocaleTimeString()}
                  </Typography>
                )}
              </Box>
              <Tooltip title="Auto-refreshes every 30 seconds to show new notifications">
                <Chip
                  icon={<AutorenewIcon />}
                  label={`Refresh in ${ticker}s`}
                  size="small"
                  color="info"
                  variant="outlined"
                />
              </Tooltip>
            </Box>

            <LinearProgress
              variant="determinate"
              value={progressValue}
              sx={{ mb: 2.5, borderRadius: 1, height: 3 }}
            />

            <Divider sx={{ mb: 2.5 }} />

            <Box sx={{ mb: 2.5 }}>
              <Typography variant="body2" fontWeight={500} sx={{ mb: 1.5 }}>
                Show top{' '}
                <Chip label={displayLimit} size="small" color="primary" sx={{ fontWeight: 700, mx: 0.5 }} />
                notifications
              </Typography>
              <Slider
                min={5}
                max={25}
                step={5}
                value={displayLimit}
                onChange={(_, v) => {
                  setDisplayLimit(v);
                  logger.info('priority-page', 'Display limit changed', { displayLimit: v });
                }}
                marks={[5, 10, 15, 20, 25].map((v) => ({ value: v, label: String(v) }))}
                sx={{ maxWidth: 400 }}
              />
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <FilterListIcon fontSize="small" color="action" />
              <Typography variant="body2" color="text.secondary" sx={{ mr: 1 }}>
                Filter:
              </Typography>
              <ToggleButtonGroup
                value={activeCategory}
                exclusive
                size="small"
                onChange={(_, val) => {
                  if (val) {
                    setActiveCategory(val);
                    logger.info('priority-page', 'Category filter changed', { activeCategory: val });
                  }
                }}
              >
                {CATEGORY_OPTIONS.map((cat) => (
                  <ToggleButton key={cat} value={cat} sx={{ px: 2 }}>
                    {cat}
                  </ToggleButton>
                ))}
              </ToggleButtonGroup>
            </Box>
          </Paper>

          {isFetching && (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
              <CircularProgress />
            </Box>
          )}

          {fetchError && (
            <Alert severity="error" sx={{ mb: 2 }} onClose={() => setFetchError(null)}>
              Failed to load: {fetchError}
            </Alert>
          )}

          {!isFetching && !fetchError && (
            <Stack spacing={1.5}>
              {rankedItems.length === 0 ? (
                <Paper elevation={0} sx={{ p: 6, textAlign: 'center', border: '1px solid #E0E0E0' }}>
                  <Typography color="text.secondary">No notifications match your filters.</Typography>
                </Paper>
              ) : (
                rankedItems.map((n, idx) => (
                  <Box key={n.ID} sx={{ display: 'flex', gap: 1.5, alignItems: 'flex-start' }}>
                    <Tooltip title={idx < 3 ? `#${idx + 1} priority` : `Rank #${idx + 1}`}>
                      <Box
                        sx={{
                          minWidth: 32,
                          height: 32,
                          borderRadius: '50%',
                          bgcolor: getRankColor(idx),
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          mt: 1.5,
                          flexShrink: 0,
                        }}
                      >
                        {idx < 3 ? (
                          <EmojiEventsIcon sx={{ fontSize: 16, color: '#333' }} />
                        ) : (
                          <Typography sx={{ fontSize: 11, fontWeight: 700, color: '#666' }}>
                            {idx + 1}
                          </Typography>
                        )}
                      </Box>
                    </Tooltip>

                    <Box sx={{ flex: 1 }}>
                      <NotificationCard
                        notification={n}
                        isRead={seenIds.has(n.ID)}
                        onToggleRead={toggleRead}
                      />
                    </Box>
                  </Box>
                ))
              )}
            </Stack>
          )}
        </Container>
      </Box>
    </>
  );
}
