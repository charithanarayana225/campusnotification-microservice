'use client';
import { useState, useEffect, useCallback } from 'react';
import {
  Container, Box, Typography, ToggleButton, ToggleButtonGroup,
  Pagination, CircularProgress, Alert, Stack, Button,
  Paper, Divider,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import FilterListIcon from '@mui/icons-material/FilterList';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import Navbar from '@/components/Navbar';
import NotificationCard from '@/components/NotificationCard';
import { fetchNotifications } from '@/lib/api';
import { logger } from '@/lib/logger';

const CATEGORY_OPTIONS = ['All', 'Placement', 'Result', 'Event'];
const PAGE_SIZE = 10;

export default function NotificationsPage() {
  const [items, setItems] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageCount, setPageCount] = useState(1);
  const [isFetching, setIsFetching] = useState(false);
  const [fetchError, setFetchError] = useState(null);
  const [seenIds, setSeenIds] = useState(new Set());

  const loadItems = useCallback(async () => {
    setIsFetching(true);
    setFetchError(null);
    logger.info('notifications-page', 'Loading notifications', { page: currentPage, selectedCategory });

    try {
      const result = await fetchNotifications({
        page: currentPage,
        limit: PAGE_SIZE,
        notification_type: selectedCategory === 'All' ? undefined : selectedCategory,
      });
      setItems(result);
      setPageCount(result.length === PAGE_SIZE ? currentPage + 1 : currentPage);
    } catch (err) {
      setFetchError(err.message);
      logger.error('notifications-page', 'Load failed', { error: err.message });
    } finally {
      setIsFetching(false);
    }
  }, [currentPage, selectedCategory]);

  useEffect(() => { loadItems(); }, [loadItems]);

  const toggleItemRead = (id) => {
    setSeenIds((prev) => {
      const updated = new Set(prev);
      if (updated.has(id)) updated.delete(id);
      else updated.add(id);
      logger.info('notifications-page', 'Toggled read status', { id, isRead: updated.has(id) });
      return updated;
    });
  };

  const markEverythingRead = () => {
    setSeenIds((prev) => {
      const updated = new Set(prev);
      items.forEach((n) => updated.add(n.ID));
      logger.info('notifications-page', 'Marked all as read', { count: items.length });
      return updated;
    });
  };

  const pendingCount = items.filter((n) => !seenIds.has(n.ID)).length;

  return (
    <>
      <Navbar unreadCount={pendingCount} />
      <Box sx={{ bgcolor: 'background.default', minHeight: '100vh', py: 4 }}>
        <Container maxWidth="md">

          <Paper elevation={0} sx={{ p: 3, mb: 3, border: '1px solid #E0E0E0' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
              <Box>
                <Typography variant="h5" fontWeight={700} color="primary">
                  All Notifications
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 0.25 }}>
                  {pendingCount > 0 ? `${pendingCount} unread` : 'All caught up!'}
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', gap: 1 }}>
                {pendingCount > 0 && (
                  <Button
                    startIcon={<DoneAllIcon />}
                    onClick={markEverythingRead}
                    variant="outlined"
                    size="small"
                  >
                    Mark all read
                  </Button>
                )}
                <Button
                  startIcon={<RefreshIcon />}
                  onClick={loadItems}
                  variant="outlined"
                  size="small"
                  disabled={isFetching}
                >
                  Refresh
                </Button>
              </Box>
            </Box>

            <Divider sx={{ mb: 2 }} />

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <FilterListIcon fontSize="small" color="action" />
              <Typography variant="body2" color="text.secondary" sx={{ mr: 1 }}>
                Filter:
              </Typography>
              <ToggleButtonGroup
                value={selectedCategory}
                exclusive
                onChange={(_, val) => { if (val) { setSelectedCategory(val); setCurrentPage(1); } }}
                size="small"
              >
                {CATEGORY_OPTIONS.map((cat) => (
                  <ToggleButton key={cat} value={cat} sx={{ px: 2 }}>
                    {cat}
                  </ToggleButton>
                ))}
              </ToggleButtonGroup>
            </Box>
          </Paper>

          {isFetching && (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
              <CircularProgress />
            </Box>
          )}

          {fetchError && (
            <Alert severity="error" sx={{ mb: 2 }} onClose={() => setFetchError(null)}>
              Failed to load notifications: {fetchError}
            </Alert>
          )}

          {!isFetching && !fetchError && (
            <>
              <Stack spacing={1.5}>
                {items.length === 0 ? (
                  <Paper elevation={0} sx={{ p: 6, textAlign: 'center', border: '1px solid #E0E0E0' }}>
                    <Typography color="text.secondary">No notifications found.</Typography>
                  </Paper>
                ) : (
                  items.map((n) => (
                    <NotificationCard
                      key={n.ID}
                      notification={n}
                      isRead={seenIds.has(n.ID)}
                      onToggleRead={toggleItemRead}
                    />
                  ))
                )}
              </Stack>

              {pageCount > 1 && (
                <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
                  <Pagination
                    count={pageCount}
                    page={currentPage}
                    onChange={(_, v) => setCurrentPage(v)}
                    color="primary"
                    shape="rounded"
                  />
                </Box>
              )}
            </>
          )}
        </Container>
      </Box>
    </>
  );
}
